"""rnfs command line (specification section 11).

`daemon` runs a node with its API and gateway; every other command is one request to a running daemon's
local API (see rnfs/api.py). Client commands never import RNS, so they start quickly; paths given to them
are resolved to absolute paths here, since the daemon reads and writes them itself.

Client commands authenticate with the token the daemon writes to <rnfs dir>/api_token at each start
(specification section 11), so only users who can read the rnfs directory can use the daemon. They send it
only once the program on the API port has proved it knows it (api_proof), since while the daemon is down
any local user could listen there.
"""
import argparse
import contextlib
import errno
import hashlib
import hmac
import http.client
import json
import os
import secrets
import stat
import sys
from urllib.parse import urlencode

from rnfs import __version__, fsutil
from rnfs.config import DEFAULT_API_PORT, Config

DEFAULT_DIR = Config.rnfs_dir
COPY_SIZE = 64 * 1024
TOKEN_FILE = "api_token"  # in the rnfs directory; written by the daemon, read by every other command
NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)  # Windows lacks it
# Before sending the token, the CLI makes whatever listens on the API port prove it knows it (api_proof)
CHALLENGE_HEADER = "X-Rnfs-Challenge"
PROOF_HEADER = "X-Rnfs-Proof"


# text with control characters escaped, so names from other people's DAGs can't drive the terminal
printable = fsutil.printable


def warn(message: str):
    """Print a warning to stderr."""
    print(f"rnfs: warning: {printable(message)}", file=sys.stderr)


def fail(message: str):
    """Exit with status 1 and an error message on stderr."""
    sys.exit(f"rnfs: {printable(message)}")


def token_path(rnfs_dir: str) -> str:
    """Where the daemon using rnfs_dir keeps its API token."""
    return os.path.join(os.path.expanduser(rnfs_dir), TOKEN_FILE)


def write_token(path: str, token: str):
    """Write the API token to path atomically, created with mode 0600 so other users can't read it."""
    # A new file (O_EXCL) in the same directory, then a rename: the token is never readable with wider
    # permissions, nor half-written, and an existing file or symlink at path is replaced, not written through
    temp = os.path.join(os.path.dirname(path), f".{TOKEN_FILE}.{os.getpid()}.{secrets.token_hex(4)}")
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | NOFOLLOW | fsutil.O_BINARY, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="ascii") as f:
            f.write(token + "\n")
        fsutil.replace(temp, path)  # retried on Windows while a client command is reading the old token
    except BaseException:
        with contextlib.suppress(OSError):
            fsutil.remove(temp)
        raise


def remove_token(path: str, token: str):
    """Delete the token file at path if it still holds token (another daemon may have replaced it)."""
    try:
        with open(path, encoding="ascii", errors="replace") as f:
            if f.read().strip() != token:
                return
        fsutil.remove(path)  # on Windows, one a client still holds open is left, and replaced at the next start
    except OSError:
        pass  # already gone, or unreadable: nothing of ours to clean up


def api_proof(token: str, port: int, challenge: str) -> str:
    """The daemon's answer to a challenge: HMAC-SHA256, keyed by the API token, of the challenge and the port
    it listens on (so a program on another port can't pass on the daemon's answer)."""
    return hmac.new(token.encode(), f"rnfs api proof {port} {challenge}".encode(), hashlib.sha256).hexdigest()


def read_token(path: str) -> str:
    """The daemon's API token from path; exits with an explanation if it can't be used."""
    try:
        fd = os.open(path, os.O_RDONLY | NOFOLLOW | fsutil.O_BINARY)
    except FileNotFoundError:
        fail(f"no API token at {path}: is the daemon running, with this --dir?")
    except PermissionError:
        fail(f"can't read the API token at {path}: permission denied. Is the daemon running as another user?")
    except OSError as e:
        fail(f"can't read the API token at {path}: {e}")
    with os.fdopen(fd, "rb") as f:
        mode = stat.S_IMODE(os.fstat(f.fileno()).st_mode)
        # Windows has no Unix permission bits to check
        if not fsutil.IS_WINDOWS and mode & 0o077:
            fail(f"{path} is accessible to other users (mode {mode:04o}), so its token can't be trusted; "
                 f"restart the daemon to make a new one")
        token = f.read(1024).decode("ascii", "replace").strip()
    if not token:
        fail(f"the API token file {path} is empty; restart the daemon")
    return token


class ApiClient:
    """Talks to the daemon's API on 127.0.0.1:port, exiting with a friendly message on any error.

    token_file is read on the first request that needs it: status needs no token, for health checks.
    """

    def __init__(self, port: int, token_file: str):
        self.port = port
        self.token_file = token_file
        self.token: str | None = None

    def request(self, method: str, path: str, params: dict | None = None, json_body: dict | None = None,
                body=None, length: int | None = None, extra_headers: dict | None = None) -> http.client.HTTPResponse:
        """Send a request and return the successful response; exits on errors.

        body may be bytes or a file; a file without length is sent chunked.
        """
        url = path + ("?" + urlencode({k: v for k, v in params.items() if v is not None}) if params else "")
        # Host is set explicitly: the API only accepts 127.0.0.1:<port>, even for port 80
        headers = {"Host": f"127.0.0.1:{self.port}", **(extra_headers or {})}
        if (method, path) != ("GET", "/api/status"):
            if self.token is None:
                token = read_token(self.token_file)
                self.verify_daemon(token)
                self.token = token
            headers["X-Rnfs-Api"] = self.token
        if json_body is not None:
            body = json.dumps(json_body).encode()
            headers["Content-Type"] = "application/json"
        elif body is not None:
            headers["Content-Type"] = "application/octet-stream"
            if length is not None:
                headers["Content-Length"] = str(length)
        connection = http.client.HTTPConnection("127.0.0.1", self.port)  # no timeout: fetches can take hours
        try:
            connection.request(method, url, body=body, headers=headers)
            response = connection.getresponse()
        except ConnectionRefusedError:
            fail(f"no daemon is running on API port {self.port}. Start one with: rnfs daemon")
        except (http.client.HTTPException, ConnectionError) as e:
            fail(f"the daemon dropped the connection ({e!r}); see its log")
        except OSError as e:
            fail(f"can't reach the daemon on API port {self.port}: {e}")
        if response.status >= 400:
            data = response.read()
            try:
                message = json.loads(data)["error"]
            except (ValueError, KeyError, TypeError):
                message = f"HTTP {response.status} {response.reason}"
            fail(message)
        return response

    def verify_daemon(self, token: str):
        """Exit unless whatever listens on the API port proves it knows token, before the token (or a name key)
        is sent to it: while the daemon is down, any local user could be listening on its port."""
        challenge = secrets.token_hex(16)
        response = self.request("GET", "/api/status", extra_headers={CHALLENGE_HEADER: challenge})
        read_all(response)
        proof = (response.getheader(PROOF_HEADER) or "").strip().encode("ascii", "replace")
        if not hmac.compare_digest(proof, api_proof(token, self.port, challenge).encode()):
            fail(f"what listens on API port {self.port} couldn't prove it knows the API token in {self.token_file}, "
                 f"so nothing was sent to it: it may be another program, or a daemon using another --dir "
                 f"(or one started before an upgrade: restart it)")

    def call(self, method: str, path: str, params: dict | None = None, json_body: dict | None = None,
             body=None, length: int | None = None):
        """Send a request and return its decoded JSON response."""
        response = self.request(method, path, params, json_body, body, length)
        try:
            return json.loads(read_all(response))
        except ValueError:
            fail("the daemon sent an invalid response")

    def get(self, path: str, /, **params):
        """GET path with query parameters; JSON response."""
        return self.call("GET", path, params=params)

    def post(self, path: str, /, **fields):
        """POST path with a JSON body; JSON response."""
        return self.call("POST", path, json_body=fields)


def read_all(response: http.client.HTTPResponse) -> bytes:
    """A response's whole body, failing if it is shorter than its Content-Length (the daemon hit an error)."""
    try:
        data = response.read()
    except http.client.IncompleteRead:
        fail("the response was cut short; see the daemon's log")
    return data


def copy_response(response: http.client.HTTPResponse, out, progress=None):
    """Copy a response body to out, failing if it ends before its Content-Length.

    progress (jobs.StreamProgress) is called with the bytes copied so far and Content-Length, and closed at the end.
    """
    expected = response.getheader("Content-Length")
    copied = 0
    while True:
        try:
            chunk = response.read(COPY_SIZE)
        except http.client.IncompleteRead:
            chunk = b""
        if not chunk:
            break
        out.write(chunk)
        copied += len(chunk)
        if progress is not None:
            progress(copied, expected)
    if progress is not None:
        progress.close()
    out.flush()
    if expected is not None and copied != int(expected):
        fail(f"the transfer stopped after {copied} of {expected} bytes; see the daemon's log")


def client(args) -> ApiClient:
    """An ApiClient for --api-port, or the api_port in <dir>/rnfs.toml, or the default port; token from <dir>."""
    port = args.api_port
    if port is None:
        try:
            port = Config.load(args.dir).api_port
        except (ValueError, TypeError, OSError) as e:  # TypeError: a badly typed setting validate() missed
            fail(f"can't read the settings in {args.dir}: {e}")
    return ApiClient(port if port is not None else DEFAULT_API_PORT, token_path(args.dir))


def port_number(text: str, minimum: int = 1) -> int:
    """A TCP port from the command line (argparse type): 1-65535, or from minimum (0: the OS picks one)."""
    try:
        port = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid port {text!r}") from None
    if not minimum <= port <= 65535:
        raise argparse.ArgumentTypeError(f"invalid port {text!r}: must be {minimum}-65535")
    return port


def absolute(path: str) -> str:
    """path made absolute here, since the daemon may run in another directory."""
    return os.path.abspath(os.path.expanduser(path))


def print_warnings(result: dict):
    """Print the warnings a daemon response carries."""
    for warning in result.get("warnings") or []:
        warn(warning)


# Daemon


def run_daemon(args):
    """Run a node with its API and gateway until SIGINT, SIGTERM or SIGBREAK, then shut everything down cleanly."""
    # Imported here so client commands don't pay for loading RNS
    import faulthandler
    import signal
    import threading

    import RNS

    from rnfs.api import ApiServer
    from rnfs.errors import RnfsError
    from rnfs.gateway import GatewayServer
    from rnfs.node import RnfsNode

    try:
        config = Config.load(args.dir, reticulum_dir=args.rnsconfig,
                             api_port=args.api_port, gateway_port=args.gateway_port,
                             bootstrap_nodes=args.bootstrap, verbosity=args.verbose or None,
                             dht_mode=args.dht_mode, slow=args.slow, private=args.private,
                             provide_strategy=args.provide_strategy,
                             gateway_scripts=False if args.no_gateway_scripts else None)
    except (ValueError, TypeError, OSError) as e:
        fail(f"invalid settings: {e}")

    try:
        node = RnfsNode(config)
    except (RnfsError, OSError) as e:  # e.g. an rnfs dir that isn't private, or an unreadable state file
        if RNS.Reticulum.get_instance() is None:
            fail(str(e))
        print(f"rnfs: {printable(str(e))}", file=sys.stderr, flush=True)
        RNS.exit(1)  # Reticulum has started: ends with os._exit, so its threads don't keep the process
    servers = []

    def abort(message: str):
        """Shut down what has started and exit with status 1 and message."""
        for server in servers:
            server.stop()
        node.stop()
        print(f"rnfs: {printable(message)}", file=sys.stderr, flush=True)
        RNS.exit(1)  # ends with os._exit, so the message is printed first

    try:
        servers.append(ApiServer(node, config.api_port))
        servers.append(GatewayServer(node, config, config.gateway_port))
    except (OSError, OverflowError) as e:  # OverflowError: a port over 65535, which validate() should have refused
        abort(f"can't listen on 127.0.0.1: {e}. Is another daemon running? (--api-port, --gateway-port)")
    api, gateway = servers
    # A new token each start, so one copied while an old daemon ran is useless now
    token_file = token_path(config.root)
    try:
        write_token(token_file, api.token)
    except OSError as e:
        abort(f"can't write the API token {token_file}: {e}")
    for server in servers:
        server.start()
    print(f"rnfs node {node.node_id.hex()}, API on http://127.0.0.1:{api.port}, "
          f"gateway on http://127.0.0.1:{gateway.port}", flush=True)
    # `kill -USR1 <pid>` prints every thread's stack, for debugging hangs. Windows has no SIGUSR1
    if hasattr(signal, "SIGUSR1"):
        faulthandler.register(signal.SIGUSR1, all_threads=True)

    # Replace RNS's handlers, which exit immediately, so the node shuts down first. On Windows, Ctrl+C is
    # SIGINT and Ctrl+Break (or CTRL_BREAK_EVENT sent to the daemon's process group) is SIGBREAK, whose
    # default would end the process at once; SIGTERM never comes from another process there
    stopping = threading.Event()
    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), lambda *_: stopping.set())
    # Python runs handlers in the main thread, and on Windows a wait isn't interrupted for them: wake each second
    while not stopping.wait(1):
        pass

    for server in servers:
        server.stop()
    remove_token(token_file, api.token)
    node.stop()
    # RNS.exit() ends with os._exit, which would lose log lines still buffered when stdout is a file
    sys.stdout.flush()
    sys.stderr.flush()
    RNS.exit()  # saves Reticulum's path table and known destinations


# Content


def add_options(args, query: bool = False) -> dict:
    """add's --no-pin, --to, --to-self, --no-sealed-name and --chunker as API parameters (only those given);
    query: for the stream endpoint's query string."""
    options: dict = {}
    if getattr(args, "no_pin", False):
        options["pin"] = 0 if query else False
    if getattr(args, "to", None):
        options["to"] = ",".join(args.to) if query else args.to
    if getattr(args, "to_self", False):
        options["to_self"] = 1 if query else True
    if getattr(args, "chunker", None):
        options["chunker"] = args.chunker
    if options.get("to") or options.get("to_self"):
        if query and args.name:
            options["seal_name"] = args.name
        elif not query and getattr(args, "no_sealed_name", False):
            options["seal_name"] = False
    return options


def wants_sealed_name(args) -> bool:
    """True if get, without -o, should write a sealed file it opens under its sealed name: a bare CID's
    output name would be the CID, while a path's last name is already a name."""
    return not args.output and not getattr(args, "raw", False) and "/" not in args.target.strip("/")


def sealed_output(args, output: str) -> str:
    """get's default output for a sealed file this node can open: its sealed name, if it has one.

    Only for a daemon without the job manager: a get job picks the sealed name itself (sealed_name), which
    doesn't cost a separate fetch of the root before the job, ignoring --from.
    """
    if not wants_sealed_name(args):
        return output
    info = client(args).get("/api/info", target=args.target, **{"from": getattr(args, "from_node", None)})
    name = info.get("name") if info.get("sealed") else None
    # The sender chose the name: no dotfiles, control characters or path tricks in the current directory
    return os.path.join(os.path.dirname(output), fsutil.safe_default_name(name, os.path.basename(output)))


def run_add(args):
    """Add a file, directory or stdin and print its CID."""
    api = client(args)
    if args.path == "-":
        if args.wrap and not args.name:
            fail("--wrap with stdin needs --name, the entry's name")
        stream = sys.stdin.buffer
        try:
            info = os.fstat(stream.fileno())
            length = info.st_size if stat.S_ISREG(info.st_mode) else None  # else sent chunked
        except (OSError, ValueError, AttributeError):
            length = None
        options = add_options(args, query=True)
        # Sealing stdin: --name is sealed inside, and is a visible wrapper entry too only with --wrap
        name = args.name if args.wrap or not (options.get("to") or options.get("to_self")) else None
        result = api.call("POST", "/api/add/stream", params={"name": name, "only_hash": int(args.only_hash), **options},
                          body=stream, length=length)
    else:
        if args.name:
            fail("--name is only for stdin (add -)")
        path = absolute(args.path)
        if not os.path.lexists(path):
            fail(f"no such file or directory: {args.path}")
        result = api.post("/api/add", path=path, wrap=args.wrap, only_hash=args.only_hash, **add_options(args))
    print_warnings(result)
    print(printable(result["cid"]))


def default_output(target: str) -> str:
    """Where `get` writes without -o: the target's last path name, else its CID, in the current directory."""
    root = target.split("/", 1)[0]
    # The last name is whoever made the DAG's choice: falls back to the CID if it is hidden (.bash_login),
    # unprintable (terminal escapes) or not one plain path component here (fsutil.safe_default_name)
    return fsutil.safe_default_name(target.rstrip("/").rsplit("/", 1)[-1], root)


def run_get(args):
    """Fetch a file or directory and have the daemon write it out, as a job (rnfs/features/jobs.py)."""
    output = absolute(args.output or default_output(args.target))
    if os.path.lexists(output):
        fail(f"{output} already exists; remove it or choose another with -o")
    from rnfs.features.contacts import node_arg  # a node contact's nick works for --from
    args.from_node = node_arg(args, args.from_node)
    if getattr(args, "raw", False):  # a sealed file's ciphertext: one request (jobs decrypt as plain get does)
        result = client(args).post("/api/get", target=args.target, output=output, raw=True, **{"from": args.from_node})
        print_warnings(result)
        print(printable(output))
        return

    def without_jobs(api) -> dict:
        """The get in one request, for a daemon without the job manager (asking for a sealed name first)."""
        final = sealed_output(args, output)
        if final != output and os.path.lexists(final):
            fail(f"{final} already exists; remove it or choose another with -o")
        return {"output": final, **api.post("/api/get", target=args.target, output=final, **{"from": args.from_node})}

    from rnfs.features import jobs
    fields = {"kind": "get", "target": args.target, "output": output, "from": args.from_node}
    if wants_sealed_name(args):
        fields["sealed_name"] = True  # the job renames a sealed file it opens to its sealed name
    result = jobs.run_transfer(args, fields, without_jobs)
    if result is not None:  # None: started in the background, its job ID printed
        print_warnings(result)
        print(printable(result.get("output") or output))


def run_cat(args):
    """Write a file, or part of one, to stdout."""
    response = client(args).request("GET", "/api/cat", params={"target": args.target, "offset": args.offset,
                                                                "length": args.length,
                                                                "raw": 1 if getattr(args, "raw", False) else None,
                                                                "block": 1 if getattr(args, "block", False) else None})
    progress = None
    if sys.stderr.isatty() and not sys.stdout.isatty():  # into a file or pipe, watched from a terminal
        from rnfs.features import jobs
        progress = jobs.StreamProgress(sys.stderr)
    try:
        copy_response(response, sys.stdout.buffer, progress)
    except OSError as e:
        # Windows reports a pipe whose reader has gone as EINVAL rather than EPIPE
        if not (isinstance(e, BrokenPipeError) or (fsutil.IS_WINDOWS and e.errno == errno.EINVAL)):
            raise
        # The reader (e.g. `head`) has gone; exit quietly without a second error at interpreter shutdown
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        sys.exit(1)


def run_ls(args):
    """List a directory: kind, size, CID and name (last, since names can contain spaces)."""
    for entry in client(args).get("/api/ls", target=args.target)["entries"]:
        name = printable(entry["name"]) + ("/" if entry["kind"] == "directory" else "")
        print(f"{printable(entry['kind']):<10} {printable(entry['size']):>12} {printable(entry['cid'])} {name}")


def print_fields(result: dict):
    """Print a JSON object as "name: value" lines."""
    for name, value in result.items():
        if isinstance(value, list):
            value = ", ".join(str(item) for item in value) if value else "none"
        print(f"{name}: {printable(value)}")


def run_stat(args):
    """Print a target's size, block count and local holdings."""
    print_fields(client(args).get("/api/stat", target=args.target))


def run_dir_set(args):
    """Make a directory with an entry added or replaced; print its CID."""
    print(printable(client(args).post("/api/dir/set", target=args.target, name=args.name, cid=args.cid,
                                      executable=args.exec)["cid"]))


def run_dir_rm(args):
    """Make a directory with an entry removed; print its CID."""
    print(printable(client(args).post("/api/dir/rm", target=args.target)["cid"]))


# Pins


def run_pin_add(args):
    """Fetch and pin a target, as a job; print its CID once complete."""
    from rnfs.features import jobs
    result = jobs.run_transfer(args, {"kind": "pin", "target": args.target},
                               lambda api: api.post("/api/pin/add", target=args.target))
    if result is not None:
        print(printable(result["cid"]))


def run_pin_rm(args):
    """Remove the user pin of a CID."""
    client(args).post("/api/pin/rm", cid=args.cid)


def display_name(name: str) -> str:
    """A pin's local name for printing: the home directory shortened to ~, non-printables escaped."""
    home = os.path.expanduser("~")
    if home not in ("", "~", os.sep) and (name == home or name.startswith(home + os.sep)):
        name = "~" + name[len(home):]
    return printable(name)


def run_pin_ls(args):
    """List pins with their sources and, when known, where each came from (or what it holds)."""
    pins = client(args).get("/api/pin/ls", cid=args.cid)["pins"]
    if args.json:
        print(json.dumps(pins, indent=2))
        return
    for pin in pins:
        state = "" if pin["complete"] else " (incomplete)"
        name = f"  {display_name(pin['name'])}" if pin.get("name") else ""
        print(f"{printable(pin['cid'])} {','.join(printable(s) for s in pin['sources'])}{state}{name}")


def run_pin_remote(args):
    """Ask a node to pin or release a CID."""
    from rnfs.features.contacts import node_arg  # a node contact's nick works as a node ID
    args.node = node_arg(args, args.node)
    result = client(args).post("/api/pin/remote", node=args.node, cid=args.cid, pin=args.action == "add")
    if not result["accepted"]:
        fail(f"{args.node} refused the request")
    print("accepted")


def run_gc(args):
    """Evict every cached fetch."""
    result = client(args).post("/api/gc")
    print(printable(f"removed {result['removed_blocks']} blocks, freed {result['freed_bytes']} bytes"))


def run_verify(args):
    """Re-check every stored block; exits with status 1 if any were bad (they are deleted)."""
    result = client(args).post("/api/verify")
    print(printable(f"checked {result['checked']} blocks"))
    for cid in result["bad"]:
        print(f"bad block deleted: {printable(cid)}")
    if result["bad"]:
        sys.exit(1)


# Network


def run_providers(args):
    """Print the IDs of nodes providing a CID, one per line."""
    providers = client(args).get("/api/providers", cid=args.cid)["providers"]
    if not providers:
        fail("no providers found")
    print("\n".join(printable(node_id) for node_id in providers))


def run_ping(args):
    """Print the round-trip time to a node."""
    from rnfs.features.contacts import node_arg  # a node contact's nick works as a node ID
    args.node = node_arg(args, args.node)
    rtt = client(args).get("/api/ping", node=args.node)["rtt"]
    if rtt is None:
        fail(f"no answer from {args.node}")
    print(f"round-trip time {rtt * 1000:.0f} ms")


# Names


def run_name_create(args):
    """Create a name key; print the name."""
    print(printable(client(args).post("/api/name/create", alias=args.alias)["name"]))


def run_name_rm(args):
    """Delete a name key, releasing its pin."""
    client(args).post("/api/name/rm", alias=args.alias)


def run_name_export(args):
    """Write a name's key to -o (created with mode 0600) or stdout."""
    if not args.output and sys.stdout.isatty():
        fail("refusing to write a private key to the terminal; use -o <file> or redirect stdout")
    response = client(args).request("POST", "/api/name/export", json_body={"alias": args.alias})
    key = read_all(response)
    if args.output:
        try:
            fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | fsutil.O_BINARY, 0o600)
        except FileExistsError:
            fail(f"{args.output} already exists")
        except OSError as e:
            fail(f"can't write {args.output}: {e}")
        with os.fdopen(fd, "wb") as out:
            out.write(key)
    else:
        sys.stdout.buffer.write(key)
        sys.stdout.buffer.flush()


def run_name_import(args):
    """Import a name key from a file or stdin; print the name."""
    if args.file == "-":
        key = sys.stdin.buffer.read()
    else:
        try:
            with open(args.file, "rb") as f:
                key = f.read()
        except OSError as e:
            fail(f"can't read {args.file}: {e}")
    result = client(args).call("POST", "/api/name/import", params={"alias": args.alias}, body=key)
    print(printable(result["name"]))


def run_name_list(args):
    """List this node's names: alias, name, CID and sequence."""
    for entry in client(args).get("/api/name/list")["names"]:
        print("\t".join(printable(value) for value in (entry["alias"], entry["name"], entry.get("cid") or "-",
                                                          entry.get("sequence", 0))))


def run_name_publish(args):
    """Point a name at a target."""
    result = client(args).post("/api/name/publish", alias=args.alias, target=args.target)
    print(printable(f"published {result['cid']} as {result['name']} (sequence {result['sequence']})"))


def run_name_resolve(args):
    """Print the CID a name points at."""
    print(printable(client(args).get("/api/name/resolve", name=args.name)["cid"]))


# Archives and status


def run_export(args):
    """Write a target and its DAG to an archive file, as a job."""
    output = absolute(args.output)
    from rnfs.features import jobs
    result = jobs.run_transfer(args, {"kind": "export", "target": args.target, "output": output},
                               lambda api: api.post("/api/export", target=args.target, output=output))
    if result is not None:
        print(printable(f"exported {result['blocks']} blocks of {', '.join(result['roots'])} to {output}"))


def run_import(args):
    """Import an archive, pinning its complete roots."""
    path = absolute(args.file)
    if not os.path.isfile(path):
        fail(f"no such file: {args.file}")
    result = client(args).post("/api/import", path=path)
    for root in result["roots"]:
        print(printable(root))
    for root in result.get("incomplete") or []:
        warn(f"{root} is incomplete in the archive, so it wasn't pinned")


def run_status(args):
    """Print the daemon's status, one "name: value" per line."""
    print_fields(client(args).get("/api/status"))


# Parser


def build_parser() -> argparse.ArgumentParser:
    """The argument parser for every command."""
    parser = argparse.ArgumentParser(prog="rnfs", description="Content-addressed file sharing over Reticulum")
    parser.add_argument("--version", action="version", version=f"rnfs {__version__}")
    parser.add_argument("--api-port", type=port_number, default=None,
                        help=f"daemon's API port (default {DEFAULT_API_PORT})")
    parser.add_argument("--dir", default=DEFAULT_DIR, help="rnfs directory (settings, identity, storage)")
    # Repeated on every subcommand so they can also go after the command name. SUPPRESS keeps a
    # subcommand's unset default from overwriting a value given before the command
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-port", type=port_number, default=argparse.SUPPRESS, help="daemon's API port")
    common.add_argument("--dir", default=argparse.SUPPRESS, help="rnfs directory")
    commands = parser.add_subparsers(dest="command", required=True, metavar="command")

    def command(subparsers, name: str, run, help: str) -> argparse.ArgumentParser:
        """Add a subcommand that runs run(args)."""
        sub = subparsers.add_parser(name, parents=[common], help=help, description=help)
        sub.set_defaults(run=run)
        return sub

    daemon = command(commands, "daemon", run_daemon, "run a node, its API and its gateway")
    daemon.add_argument("--bootstrap", nargs="+", action="extend", metavar="NODE_ID",
                        help="node IDs (hex) to join the DHT through")
    daemon.add_argument("--gateway-port", type=lambda text: port_number(text, minimum=0),
                        help="gateway port (default 8789; 0: any free port)")
    daemon.add_argument("--rnsconfig", metavar="DIR",
                        help="Reticulum config directory (default: RNS's own, the one rnsd uses)")
    daemon.add_argument("--dht-mode", choices=["server", "client"])
    daemon.add_argument("--slow", choices=["yes", "no", "auto"])
    daemon.add_argument("--private", action="store_true", default=None, help="private mode: members only")
    daemon.add_argument("--provide-strategy", choices=["pinned", "roots"])
    daemon.add_argument("--no-gateway-scripts", action="store_true", help="don't let gateway pages run scripts")
    daemon.add_argument("-v", "--verbose", action="count", default=0,
                        help="log more detail: -v for every DHT query, -vv for RNS debug output")

    add = command(commands, "add", run_add, "add a file, directory or stdin (-), pin it and print its CID")
    add.add_argument("path", help="file or directory, or - for stdin")
    add.add_argument("--wrap", action="store_true", help="put it in a directory")
    add.add_argument("--only-hash", action="store_true", help="just print the CID; store nothing")
    add.add_argument("--name", help="with stdin: wrap it in a directory as this entry")
    # --- content: unpinned adds, sealed files, chunkers ---
    add.add_argument("--no-pin", action="store_true", help="keep it as evictable cache instead of pinning it")
    add.add_argument("--to", nargs="+", action="extend", metavar="RECIPIENT",
                     help="seal it so only these can read it: rnfs node IDs, LXMF addresses or identity hashes "
                          "RNS has heard, 128-hex public keys, or contact nicks")
    add.add_argument("--to-self", action="store_true", help="seal it for this node's identity too")
    add.add_argument("--no-sealed-name", action="store_true", help="with --to: don't seal the file name inside")
    add.add_argument("--chunker", choices=["fixed", "fastcdc"], help="fixed 64 KiB chunks (default) or FastCDC "
                     "content-defined chunks, which keep most chunks of an edited file unchanged")

    get = command(commands, "get", run_get, "fetch and write out a file or directory")
    get.add_argument("target", metavar="CID[/PATH]")
    get.add_argument("-o", "--output", help="where to write (default: the last path name or the CID, here)")
    get.add_argument("--from", dest="from_node", metavar="NODE_ID", help="fetch from this node, bypassing the DHT")
    get.add_argument("--background", action="store_true", help="start a job, print its ID and return (rnfs jobs)")
    get.add_argument("--raw", action="store_true", help="a sealed file as stored (its ciphertext), not decrypted")

    cat = command(commands, "cat", run_cat, "write a file, or part of one, to stdout")
    cat.add_argument("target", metavar="CID[/PATH]")
    cat.add_argument("--offset", type=int, default=None, help="first byte to write")
    cat.add_argument("--length", type=int, default=None, help="number of bytes to write")
    cat.add_argument("--raw", action="store_true", help="a sealed file as stored (its ciphertext), not decrypted")
    cat.add_argument("--block", action="store_true", help="the CID's own block (a bare CID), verified")

    ls = command(commands, "ls", run_ls, "list a directory: kind, size, CID, name")
    ls.add_argument("target", metavar="CID[/PATH]")

    stat_ = command(commands, "stat", run_stat, "size, block count, and how much is held locally")
    stat_.add_argument("target", metavar="CID[/PATH]")

    dir_ = commands.add_parser("dir", help="edit directories (making new ones)").add_subparsers(
        dest="dir_command", required=True, metavar="command")
    dir_set = command(dir_, "set", run_dir_set, "make a directory with an entry added or replaced")
    dir_set.add_argument("target", metavar="CID[/PATH]", help="the directory")
    dir_set.add_argument("name", help="entry name")
    dir_set.add_argument("cid", help="the entry's CID")
    dir_set.add_argument("--exec", action="store_true", help="mark the entry executable")
    dir_rm = command(dir_, "rm", run_dir_rm, "make a directory with an entry removed")
    dir_rm.add_argument("target", metavar="CID/PATH", help="the entry to remove")

    pin = commands.add_parser("pin", help="manage pins").add_subparsers(dest="pin_command", required=True,
                                                                        metavar="command")
    pin_add = command(pin, "add", run_pin_add, "fetch and pin")
    pin_add.add_argument("target", metavar="CID[/PATH]")
    pin_add.add_argument("--background", action="store_true", help="start a job, print its ID and return (rnfs jobs)")
    pin_rm = command(pin, "rm", run_pin_rm, "remove the user pin")
    pin_rm.add_argument("cid")
    pin_ls = command(pin, "ls", run_pin_ls, "list pins, their sources and where each came from")
    pin_ls.add_argument("cid", nargs="?")
    pin_ls.add_argument("--json", action="store_true", help="print the full listing as JSON")
    remote = pin.add_parser("remote", help="remote pinning").add_subparsers(dest="action", required=True,
                                                                            metavar="command")
    for action in ("add", "rm"):
        sub = command(remote, action, run_pin_remote, f"ask a node to {'pin' if action == 'add' else 'unpin'} a CID")
        sub.add_argument("node", metavar="NODE_ID")
        sub.add_argument("cid")

    command(commands, "gc", run_gc, "evict all cached fetches")
    command(commands, "verify", run_verify, "re-check every stored block against its CID")

    providers = command(commands, "providers", run_providers, "find nodes providing a CID")
    providers.add_argument("cid")
    ping = command(commands, "ping", run_ping, "report the round-trip time to a node")
    ping.add_argument("node", metavar="NODE_ID")

    name = commands.add_parser("name", help="mutable names").add_subparsers(dest="name_command", required=True,
                                                                            metavar="command")
    for action, run, help in (("create", run_name_create, "create a name key"),
                              ("rm", run_name_rm, "delete a name key and release its pin")):
        command(name, action, run, help).add_argument("alias")
    name_export = command(name, "export", run_name_export, "write a name's key to stdout or -o")
    name_export.add_argument("alias")
    name_export.add_argument("-o", "--output", help="file to create (mode 0600)")
    name_import = command(name, "import", run_name_import, "import a name key from a file or stdin")
    name_import.add_argument("alias")
    name_import.add_argument("file", nargs="?", default="-", help="key file (default: stdin)")
    command(name, "list", run_name_list, "list this node's names")
    publish = command(name, "publish", run_name_publish, "point a name at a CID")
    publish.add_argument("alias")
    publish.add_argument("target", metavar="CID[/PATH]")
    resolve = command(name, "resolve", run_name_resolve, "print the CID a name points at")
    resolve.add_argument("name", help="the name (32 hex characters) or a name contact's nick")

    export = command(commands, "export", run_export, "write an archive of a target")
    export.add_argument("target", metavar="CID[/PATH]")
    export.add_argument("-o", "--output", required=True, help="archive file to write")
    export.add_argument("--background", action="store_true", help="start a job, print its ID and return (rnfs jobs)")
    import_ = command(commands, "import", run_import, "import an archive, pinning its roots")
    import_.add_argument("file")

    command(commands, "status", run_status, "node ID, known nodes, records held, storage use")

    from rnfs import features
    for feature in features.feature_classes():
        feature.cli_commands(commands, command)
    return parser


def main(argv: list[str] | None = None):
    """Parse the command line and run the chosen command."""
    # Redirected output on Windows uses the ANSI code page, which can't encode every name: escape what it
    # can't rather than fail part-way through a listing
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="backslashreplace")
    args = build_parser().parse_args(argv)
    args.run(args)


if __name__ == "__main__":
    main()
